export class RegisterUser {
    firstname: string;
    lastname: string;
    dateofbirth: string;
    address: string;
    contactno: number;
    email: string;
    password: string;
    confirmPassword: string;
}
