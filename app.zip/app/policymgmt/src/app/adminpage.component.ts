import { Component } from '@angular/core';

@Component({
  templateUrl: './adminpage.component.html'
})
export class AdminPageComponent {
}
