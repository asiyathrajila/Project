package com.pms.db;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.logging.Logger;

/**
 * Loads the properties 
 *
 * @author Asiyath A
 *
 */
public class PropertiesConfig {

	static final Logger logger = Logger.getLogger("PropertiesConfig.class");
	private static PropertiesConfig singleton = new PropertiesConfig();

	String db_url;
	String db_user;
	String db_passwd;

	
	Properties prop = new Properties();

	private PropertiesConfig() {
		init();
	}

	/**
	 * return instance
	 * @return
	 */
	public static PropertiesConfig getInstance() {
		return singleton;
	}

	void init() {
		logger.info("Initiazling Properties");

		InputStream input = null;

		try {
			input = getClass().getClassLoader().getResourceAsStream("config.properties");

			prop.load(input);

		} catch (IOException ex) {
			logger.info("Failed to initialize : " + ex.getMessage());
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}


	/**
	 * Get property value for property name
	 * 
	 * @param propertyName
	 * @return
	 */
	public String getProperty(String propertyName) {
			logger.info("Get property : "+ propertyName);
		
		return prop.getProperty(propertyName);
	}

}