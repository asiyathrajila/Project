package com.pms.db;

import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.mysql.jdbc.Connection;



/**
 * 
 * @author Asiyath
 *
 */
public class DbConnection {

	static final Logger logger = Logger.getLogger(DbConnection.class);
	private PropertiesConfig properties = PropertiesConfig.getInstance();
	private static DbConnection singleton = new DbConnection();

	String db_url; //  jdbc db url
	String db_user; // db username
	String db_passwd; // db password

	boolean db_init = false;
	
	private Connection connection = null;

	private DbConnection() {
		db_url = properties.getProperty("database.url");
		db_user = properties.getProperty("database.user");
		db_passwd = properties.getProperty("database.passwd");

		initDatabase();
	}

	private void initDatabase() {
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			connection = (Connection) DriverManager.getConnection(db_url, db_user, db_passwd);
			
			logger.info("DATABASE : Connection Successful.");
			
			db_init = true; 
		} catch (SQLException e) {
			logger.error("Failed to initialize db : " + e.getMessage());
		} catch (Exception ex) {
			logger.error("Error : " + ex.getMessage());
		}
	}

	/**
	 * Return instance
	 * 
	 * @return
	 */
	public static DbConnection getInstance() {
		return singleton;
	}

	/**
	 * Get DB connection object
	 * 
	 * @return
	 * @throws Exception
	 */
	public Connection getConnection() throws Exception {
		if (db_init) {
			return connection;
		}
		
		return null;
	}
}