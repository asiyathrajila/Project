package com.pms.webservices.rest.jersey;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.pms.db.DbConnection;
import com.pms.model.User;

/**
 * User managing functions
 * 
 * @author Asiyath
 *
 */
public class UserManager {

	static final Logger logger = Logger.getLogger(UserManager.class);

	Connection dbConnection = null;

	boolean isValid = true;

	public UserManager() {
		DbConnection database = DbConnection.getInstance();
		try {
			dbConnection = database.getConnection();
		} catch (Exception e) {
			logger.error("Failed to get connection.");
			dbConnection = null;
			setValid(false);
		}
	}

	public boolean isValid() {
		return isValid;
	}

	public void setValid(boolean isValid) {
		this.isValid = isValid;
	}

	/**
	 * Get user
	 * 
	 * @param userId
	 * @return User <OR> ERROR <OR> null
	 */
	public User getUser(int userId) throws Exception {

		if (!isValid()) {
			logger.warn("DB connection is not available");
			return null;
		}

		if (userId < 1) {
			logger.warn("Invalid userId : " + userId);
			return null;
		}

		User user = null;
		try {
			PreparedStatement ps = dbConnection.prepareStatement("SELECT * FROM user WHERE user_id = ?");
			ps.setInt(1, userId);


			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				user = new User();
				user.setUser_id(rs.getInt("user_id"));
				user.setLogin(rs.getString("login"));
				user.setName_1(rs.getString("name_1"));
				user.setName_2(rs.getString("name_2"));
				user.setAddress(rs.getString("address"));
				user.setPhone(rs.getString("phone_1"));
				user.setEmail(rs.getString("email"));
				user.setPassword(rs.getString("password"));
				user.setDob(rs.getDate("dob"));
				user.setType(rs.getInt("type"));
			}
		} catch (Exception e) {
			throw e;
		}

		logger.debug("User+ : " + user);
		return user;

	}

	/**
	 * Get user for login
	 * 
	 * @param userId
	 * @return User <OR> ERROR <OR> null
	 */
	public User getUserForLogin(String login) throws Exception {

		if (!isValid()) {
			logger.warn("DB connection is not available");
			return null;
		}

		if (login == null || login.length() < 1) {
			logger.warn("Invalid login");
			return null;
		}

		User user = null;
		try {
			PreparedStatement ps = dbConnection.prepareStatement("SELECT * FROM user WHERE login = ?");
			ps.setString(1, login);

			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				user = new User();
				user.setUser_id(rs.getInt("user_id"));
				user.setLogin(rs.getString("login"));
				user.setName_1(rs.getString("name_1"));
				user.setName_2(rs.getString("name_2"));
				user.setAddress(rs.getString("address"));
				user.setPhone(rs.getString("phone_1"));
				user.setEmail(rs.getString("email"));
				user.setPassword(rs.getString("password"));
				user.setDob(rs.getDate("dob"));
				user.setType(rs.getInt("type"));
			}
		} catch (Exception e) {
			throw e;
		}

		logger.debug("User+ : " + user);
		return user;

	}

	/**
	 * Check whether the login already exists
	 * 
	 * @param login
	 * @return boolean
	 */
	public boolean loginExists(String login) throws Exception {

		if (!isValid()) {
			logger.warn("DB connection is not available");
			throw new Exception("No DB Connection");
		}

		if (login == null || login.length() < 1) {
			logger.warn("Invalid login name : " + login);
			throw new Exception("Invalid login name");
		}

		try {
			PreparedStatement ps = dbConnection.prepareStatement("SELECT * FROM user WHERE login = ?");
			ps.setString(1, login);

			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				return true;
			}
		} catch (Exception e) {
			throw e;
		}

		logger.debug("No user exists with login : " + login);
		return false;
	}

	/**
	 * Add/Update User
	 * 
	 * @param user
	 * @param isUpdate
	 * @return <user_id> OR ERROR
	 */
	public int addUser(User user, boolean isUpdate) throws SQLException, Exception {

		if (!isValid()) {
			logger.warn("DB connection is not available");
			return -1;
		}

		int user_id = -1;

		if (user == null) {
			logger.warn("Invalid user object");
			return user_id;
		}

		try {
			String query = null;
			if (isUpdate) {
				query = " UPDATE user SET name_1 = ?, name_2 = ?, address = ?, phone_1 = ?, email = ?, password = ?, dob = ?, type = ? WHERE user_id = ?";
				logger.debug("Updating record");
			} else {
				// Insert record
				query = " INSERT INTO user(login, name_1, name_2, address, phone_1, email, password, dob, type)"
						+ " values (?, ?, ?, ?, ?, ?, ?, ?, ?)";
				logger.debug("Inserting record");
			}

			// create the mysql insert preparedstatement
			PreparedStatement preparedStmt = dbConnection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);

			if (!isUpdate) { // Add
				preparedStmt.setString(1, user.getLogin());
				preparedStmt.setString(2, user.getName_1());
				preparedStmt.setString(3, user.getName_2());
				preparedStmt.setString(4, user.getAddress());
				preparedStmt.setString(5, user.getPhone());
				preparedStmt.setString(6, user.getEmail());
				preparedStmt.setString(7, user.getPassword());
				preparedStmt.setDate(8, user.getDob());
				preparedStmt.setInt(9, user.getType());
			} else {
				preparedStmt.setString(1, user.getName_1());
				preparedStmt.setString(2, user.getName_2());
				preparedStmt.setString(3, user.getAddress());
				preparedStmt.setString(4, user.getPhone());
				preparedStmt.setString(5, user.getEmail());
				preparedStmt.setString(6, user.getPassword());
				preparedStmt.setDate(7, user.getDob());
				preparedStmt.setInt(8, user.getType());
				preparedStmt.setInt(9, user.getUser_id());
			}

			int affectedRows = preparedStmt.executeUpdate();
			if (affectedRows == 0) {
				throw new SQLException("Creating/Updating user failed, no rows affected.");
			}

			logger.debug("Insert/Update successful.");

			if (!isUpdate) {
				// Now get the userId which is automatically generated (auto
				// increment)
				try (ResultSet generatedKeys = preparedStmt.getGeneratedKeys()) {
					if (generatedKeys.next()) {
						user_id = generatedKeys.getInt(1);
					} else {
						throw new SQLException("Creating user failed, no ID obtained.");
					}
				}
			} else {
				user_id = user.getUser_id();
			}
		} catch (Exception e) {
			throw e;
		}

		logger.debug("user_id : " + user_id);

		// returns the newly generated user_id
		return user_id;
	}
}