package com.pms.application;

import org.glassfish.jersey.server.ResourceConfig;

import com.pms.filter.RestAuthenticationFilter;

public class CustomApplication extends ResourceConfig {
	public CustomApplication() {
		packages("com.jersey.jaxb");
		packages("com.fasterxml.jackson.jaxrs.json");
		packages("org.policymanager");
		register(com.pms.filter.GsonMessageBodyHandler.class);
		register(RestAuthenticationFilter.class);
	}
}