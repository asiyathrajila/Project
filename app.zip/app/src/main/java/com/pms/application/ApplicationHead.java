package com.pms.application;

import java.io.Serializable;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import com.pms.db.DbConnection;
import com.pms.db.PropertiesConfig;

public class ApplicationHead  extends HttpServlet implements Serializable{

	/**
	 * Application Trigger point
	 * 
	 * @author Asiyath
	 */

	private static final long serialVersionUID = 1L;

	static final Logger logger = Logger.getLogger("ApplicationHead.class");

	public void init() throws ServletException {
		logger.info("Application Starting up ....");

		loadProperties();

		init_database();
	}

	private void loadProperties() {
		// Just load the properties
		PropertiesConfig properties = PropertiesConfig.getInstance();
	}

	private void init_database() {
		DbConnection dbConnect = DbConnection.getInstance();

		try {
			if (dbConnect.getConnection() != null) {
				logger.info("Database connection tested.");
			}
		} catch (Exception e) {
			logger.info("Error in DB test :" + e.getMessage());
		}

	}
}